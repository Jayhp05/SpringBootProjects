package com.springbootstudy.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootstudyApp02Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootstudyApp02Application.class, args);
	}

}
